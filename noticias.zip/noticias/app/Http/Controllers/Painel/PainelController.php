<?php

/**
 * Created by PhpStorm.
 * User: Ayrtun Augusto
 * Date: 15/08/2019
 * Time: 18:43
 */
    namespace App\Http\Controllers\Painel;

    use Illuminate\Http\Request;
    use App\Http\Controllers\Controller;

    class PainelController extends Controller
    {
    //

    }