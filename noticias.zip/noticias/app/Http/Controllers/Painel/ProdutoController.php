<?php
/**
 * Created by PhpStorm.
 * User: Ayrtun Augusto
 * Date: 15/08/2019
 * Time: 20:21
 */

namespace App\Http\Controllers\Painel;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Painel\Product;
use App\Http\Requests\Painel\ProductFormRequest;

//mostrar como capturar dados de diferentes tipos de formul�rios
//clicar em cadastrar manda para rota de cadastro
//dependecia esta dentro de product
//controller gerada para controle de produtos.O controller passa as responsabilidades.Por exemplo a view recebe a responsabilidade.

class ProdutoController
{
    /*
        private $product(esse1);
    //Ao inves de colocar o di no index posso colocar um construtor na classe
    public function __construct(Product $product(isso aqui)){
        $this->product(esse1) = $product(isso aqui);
    Esse funcionalidade permite outras fun��es obterem esse parametros
        o di continua funcionando.
    }
     */
    private $product;
    //Ao inves de colocar o di no index posso colocar um construtor na classe
    public function __construct(Product $product){
        $this->product = $product;
    }
    public function index() {

        $title = 'Listagem dos produtos';
        //para recuperar o produtos no banco de dados apenas injetar as depend�ncias dentro de index
        //return 'Listagem dos produtos';
        //metodo all recupera todos os dados da tabela
        //depois adiciona os dados de table em products
        //lista os dados e passa para view.
        $products = $this->product->all();

        return view('painel.products.index', compact('products', 'title')); //Controller manda os dados para view
    }
    public function create(){ //formul�rio para cadastrar

        $title = 'Cadastrar novo produto';

        $categorys = ['eletronicos', 'moveis', 'limpeza', 'banho'];

        return view('painel.products.create-edit', compact('title', 'categorys'));
    }
    //Ao inv�s de injetar request injeta public function store(Request $request)  injeta ProductFormRequest
    public function store(ProductFormRequest $request) {
        //di dependencia injection cria o objeto Resquest e atribui a $request com isso tem o objeto request nessa classe
        //\App\User $user
        //$user = new \App\User(); acrescentando isso entre parentes nao precisa digitar user sempre.
        //dd($request->all());
        //dd($request->only(['name', 'number']));
        //dd($request->except(['token', 'category']));
        //dd($request->input('name'));
        //

        //Pega todos os dados que vem do formul�rio.
        //$dataForm = $request->all();
        //
        //$dataForm = $request->except('_token');
        //$insert = $this->product->insert($dataForm);

        $dataForm = $request->all();

        $dataForm['active'] = ( !isset($dataForm['active']) ) ? 0 : 1;

        //messages guardam as mensagens de erro.
/*        $messages   =   [
            'name.required'     =>  'O campo nome � obrigat�rio',
            'number.required'   =>  'Precisa ser apenas n�meros',
            'number.required'   =>  'O campo n�mero � de preenchimento obrigat�rio',
        ];*/

        //importante que valide os dados abaixo e tenha certeza que o dataform seja algo que pode ser inserido no banco de dados
        //sem preocupa��o.
        //Valida os dados.
        //rules s�o regras de valida��o que podem ficar tanto na model de products
        //esse m�todo n�o � o certo de usar por�m ir� funcionar. As regras de controle n�o ficam na model mas na controller.
        //o laravel tem um recurso que deixa essa funcionalidade em uma classe espec�fica da aplica��o.
        //Mostrar na view abaixo os erros de valida��o n�o aprovado por rules.
        //$this->validate($request, $this->product->rules);

        //Utilizar valida��o de maneira manual.
        //Defini��o de regra. N�o ser� validado apartir daqui. Maneira mais trabalhosa abaixo.
        //fica preso ao que oferece mas nao funcionou na vers�o atual
        //$this->validate($request, $this->product->rules);
        //Personalizando a terceira mensagem � poss�vel personalizar a mensagem.
        //O laravel outro recurso deixando uma classe para valida��o de erros. Pode alavancar com a aplica��o as regras de acl
        //pode verificar se a pessoa pode alterar aquela determinada opera��o naquele mesmo controller ou onde a pessoa faz aquela valida��o.
        //alternativa bem �til que deve explorar.
        //mostrar como capturar dados de diferentes tipos de formul�rios
        //clicar em cadastrar manda para rota de cadastro
//        $validate = validator($dataForm, $this->product->rules, $messages);
//        if($validate->fails()   )  {
//            return redirect()
//                ->route('produtos.create') //Encaminhar o usu�rio para onde quiser.
//                ->withErrors($validate) //personalizar mensagens de erro de uma outra maneira
//                ->withInput(); //

//        }
        $insert = $this->product->create($dataForm);

        if( $insert )
                //return redirect('/painel/productos')->route(); dessa forma daria certo mas pela rota ficaria mais simples.
                return redirect()->route('produtos.index');
        else
                return redirect()->back()->route('produtos.create');
        //return 'Cadastrando...';
    }

    public function show(Request $request){ //mostrar produto

    }
    public function edit($id){

        //editar produto
        //ja tem um id do produto aqui
        //Primeiro passo recuperar o item em espec�fico e pegar esse item e mandar para o formul�rio
        //preencher o formul�rio com os dados do formul�rio que j� os dados dele e quando pessoal mandar enviar
        //vou editar esse formul�rio
        //return "Editar item {$id}";
        //recuperar usu�rio pelo id
        //recuperando um produto cujo o id esteja passando por aqui.

        $product = $this->product->find($id);

        $title = "Editar produto: {$product->name}";

        $categorys = ['eletronicos', 'moveis', 'limpeza', 'banho'];

        return view('painel.products.create-edit', compact('title', 'categorys', 'product'));

    }
    public function update(ProductFormRequest $request, $id){

            //esse m�todo update n�o recebe requisi��o do tipo post
            //apenas requisi��es do tipo put ou path

            //metodo find recupera item pelo id
            //Recupera todos os dados do formul�rio
            $dataForm = $request->all();

            //Recupera o item para editar
            $product = $this->product->find($id);
            //Pode ser passado a mensagem de erro with();/ Passa um array com a mensagem errors.

            //Verifica se o produto est� ativado
            $dataForm['active'] = ( !isset($dataForm['active']) ) ? 0 : 1;

            //Verifica se realmente editou.
            $update = $product->update($dataForm);

            if( $update )
                return redirect()->route('produtos.inex');
            else
                return redirect()->route('produtos.edit', $id)->with(['errors' => 'Falha ao editar']);



        //    return "Editando o item {$id}";
    }
    public function destroy($id){

    }

    public function tests()
    {
        /*
         * trabalho improdutivo
        $prod = $this->product;
        $prod->name = 'Nome do Produto';
        $prod->number = 131231;
        $prod->active = 1;
        $prod->category =  'eletronicos';
        $prod->description = 'Description dos produtos aqui';
        $insert = $prod->save();//metodo para salvar no banco de dados.Informa true ou false
        //classe db e apartir dela consigo fazer v�rias opera��es com banco de dados.
        if($insert)
            return 'Inserido com sucesso';
        //Fun��o utilizada para testes.
        else
            return 'Falha ao inserir dados';
        */
        //modelo mais cl�ssico e recomendado pelo instrutor para inser��o de dados.
        //O tipo de inser��o abaixo coloca a aplica��o em risco. Dizer para o projeto quais colunas ser�o adicionadas supondo que
        //tenha uma coluna chamada acm e coloca false para admin e crie uma coluna falsa. E consegue inserir no banco de dados.Ao inv�s de
        //colocar insert coloca create.
        //create definir
        //dizer na controler produtos quais campos podem ser passados ao usu�rio.

      /*  $insert = $this->product->create([
                        'name'          => 'Nome do Produto 3',
                        'number'        =>  248249,
                        'active'        =>  true,
                        'category'      => 'eletronicos',
                        'description'   =>  'Description vem aqui',
                        ]);
        if( $insert )
            return "Inserido com sucesso, ID: {$insert->id}";
        else
            return 'Falha ao inserir';
      */


        //$prod = $this->product->find(5);
        //dd($prod->name);
       /* $prod = $this->product->find(5);
        $prod->name = 'Update 2';
        $prod->number = 797890;
        $prod->active = true;
        $prod->category =  'eletronicos';
        $prod->description = 'Desc update';
        $insert = $prod->save();

        if($insert)
            return 'Inserido com sucesso';
        else
            return 'Falha ao inserir dados';*/
        //M�todo mais produtivo de trabalhar.
        //pode ser feito em cascata obtendo o retorno.
/*        $prod = $this->product->find(6);
        $update = $prod->update //retorna true ou false
        ([
            'name'          => 'Update test',
            'number'        =>  6765756,
            'active'        =>  true,
        ]);

        if($update)
            return 'Inserido com sucesso';
        else
            return 'Falha ao inserir dados';*/
        //Novo cen�rio utilizando o valor durante compara��o e obten��o.
/*
        $prod = $this->product->find(3);
        //Pode ser utilizado tanto o m�todo delete quanto o destroy. Obter� o mesmo resultado.
        $delete = $prod->delete();

        if ( $delete )
                return 'Deleteado com sucesso';
        else    return 'Falha ao deletar';*/


        $delete = $this->product
            ->where('number', 67657560)
            ->delete();
        //Pode ser utilizado tanto o m�todo delete quanto o destroy. Obter� o mesmo resultado.
        if ( $delete )
            return 'Deleteado com sucesso 2';
        else    return 'Falha ao deletar';

    }
}