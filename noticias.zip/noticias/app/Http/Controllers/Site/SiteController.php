<?php
/**
 * Created by PhpStorm.
 * User: Ayrtun Augusto
 * Date: 15/08/2019
 * Time: 17:30
 */

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SiteController extends Controller
    {
        public function __construct()
        {
            /*
            $this->middleware('auth')
            ->only([
                'contato',
                'categoria'
            ]);
            $this->middleware('auth')
                ->except([
                    'index',
                    'contato'
                ]);
            */

            //como passar dados para view?
            //Bem f�cil fazer isso!
            //array teste recebe a vari�vel $teste.
            //maneira mais simples de passar vari�veis
            /*  $teste  = 123;
                $teste2 =   321;
                $teste3 = 132;
             *  return view('site.home.teste', compact('$teste', '$teste2', '$teste3'));
            $teste = 123;
            return view('teste',['teste' => $teste]); //Assim que rotas precisam ficar mais enxutas. toda vez que usar view fica dentro de helper so clicar e abrir a classe
            //para verificar arquivo assim. tem varios metodos que ajuda muito na doc tem mais info.
            */
        }


        public function index()
        {
            $tituloarb = 'Titulo teste';
            //$teste = 123;
            //return view('site.home.index',['teste' => $title]);
            //$xss = '<script>alert("Ataque XSS");</script>';

            $var1 = '123';

           $dados = [1,2,3,4,5];

            return view('site.home.index', compact('tituloarb', 'xss', 'var1', 'dados'));
        }

        public function contato()
        {
            return view('site.contato.index');
        }
        public function categoria($id)
        {
            return "Listagem dos posts da categoria: {$id}";
        }
        public function categoriaOp($id = 10)
        {
            return "Listagem dos posts da categoria: {$id}";
        }
    }
