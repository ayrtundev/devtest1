<?php

namespace App\Models\Painel;

use Illuminate\Database\Eloquent\Model; //\Eloquent modelo de manipula��o de banco de dados se tivesse utilizadado o n teria criado o migration
//se o nome da classe fosse o mesmo do atributo seria necess�rio criar o atributo protegido passando como par�metro.
//filable lista branca(passam campos que podem ser preenchidos) e possui a lista negra guarded(campos nao podem ser preenchidos


class Product extends Model
{
    //
    protected $fillable = [
        'name', 'number', 'active', 'category', 'description'
    ];
    //protected $ guarded = ['admin'];

    //conter todas regras de valida��o dos campos. atributo
/*    public $rules   =   [

        'name'          =>   'required|min:3|max:100',
        'number'        =>   'required|numeric',
        'category'      =>   'required',
        'description'   =>    'min:3|max:1000',

    ];*/
}
