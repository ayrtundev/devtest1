<!doctype html>
<html>
        <head>
            <title><?php echo e(isset($title) ? $title : 'Painel Curso'); ?></title>
            <!-- Bootstrap  -->
            <link rel="stylesheet"
                  href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
                  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            <!-- Pode usar abaixo public_path()'-->
            <link rel="stylesheet"href="<?php echo e(url('assets/painel/css/style.css')); ?>">
        </head>

        <body>
            <div class="container"></div>
                <?php echo $__env->yieldContent('content'); ?>

        </body>
</html>