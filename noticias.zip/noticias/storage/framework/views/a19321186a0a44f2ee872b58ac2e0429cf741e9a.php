<!-- Jamais fazer abertura de arquivos php aqui dentro. � feio isso  Aqui � feito o html -->

;

    <?php $__env->startSection('content'); ?>
        <!-- Aqui vem a m�gina tudo que for colocado dentr section ser� copiado do template -->
    <h1>Home page do site</h1>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('site.templates.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>