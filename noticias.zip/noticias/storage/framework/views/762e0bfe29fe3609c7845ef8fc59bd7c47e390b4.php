<!-- Jamais fazer abertura de arquivos php aqui dentro. � feio isso  Aqui � feito o html -->



    <?php $__env->startSection('content'); ?>
        <!-- Aqui vem a m�gina tudo que for colocado dentr section ser� copiado do template -->
    <h1>Home page do site</h1>
 <!--   Usar esse caso quando a vari�vel n�o colocar em risco nosso sistema  -->
    <?php if($var1 == '122' ): ?>
    <p>e igual</p>
        <?php else: ?>
        <p>diferente</p>
        <?php endif; ?>
        <?php if (! ( $var1 == 1234)): ?>
            <p>Nao e igual....unless</p>
            <?php endif; ?>
        <?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Valor: <?php echo e($array); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php $__env->startPush('scripts'); ?>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            <?php $__env->stopPush(); ?>    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('site.templates.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>