<!-- Jamais fazer abertura de arquivos php aqui dentro. � feio isso  Aqui � feito o html -->
<doctype html>
    <head>
        <meta charset="utf-8">
<h1>Homepage do site</h1>
    <?php echo e($teste); ?>  -   <?php echo e($teste2); ?> -   <?php echo e($teste3); ?>

    </head>
</doctype>