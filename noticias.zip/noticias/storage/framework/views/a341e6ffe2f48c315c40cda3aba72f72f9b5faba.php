    <!DOCTYPE html>
    <!-- <charset = 'utf-8'>'-->
<html>
    <head>
        <title> <?php echo e(isset($tituloarb) ? $tituloarb : 'Curso de Laravel 5.3'); ?> </title>
    </head>
    <body>
        <!-- usar esse arquivo como template do site    nunca utilizar na entrada de usu�rio-->

        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>

    </body>
</html>
