<?php $__env->startSection('content'); ?>

    <doctype  html>

<!--        <charset utf-8> importante deixar como post(tenta forjar envio de dado, nao enviou token, especificar
 token se � autentico) o metodo devido ao ataque crf erro proposital -->

    <h1 class="title-pg">Gest�o de produtos</h1>
        <!-- Verificar uma vari�vel quando enviado para c� envia errors. o erro de tabula��o s�o recuperados pelo loops
           a recupera��o de dados � feito dentro de if.
           -->
        <?php if( isset($errors) && count($errors) > 0  ): ?>
            <div class="alert alert-danger">
                
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

       <?php if( isset($product) ): ?>
                <form class="form" method="post" aciton="<?php echo e(route('produtos.update',$product->id)); ?>">
                    <!-- passa esse m�todo para update. � um helper -->

                    <?php echo method_field('PUT'); ?>


                    <?php else: ?>
                            <form class="form" method="post" action="<?php echo e(route('produtos.store')); ?>">
                                <?php endif; ?>

    <!-- Meios para utiliza��o ap�s method="post"  {url{('/painel/produtos')}}  <input type="hidden" name="_token"
    value="csrf_token()"> -->
    <form class="form"  method="post"    action="<?php echo e(route('produtos.store')); ?>">
        <!-- <input type="hidden" name="_token" value="{csrf_token()}">   ou (!! !!) -->
        <?php echo csrf_field(); ?>

        <div class="form group">
            <!-- Existe um objeto com product name caso n�o exista utilizo o old. Essa mesma l�gica posso utilizar para os outros itens tamb�m {$product->name or -->
            <input type="text" name="name" placeholder="Nome:" class="form-control" value="<?php echo e(isset($product->name) ? $product->name : old('description')); ?>">
        </div>

        <div class="form-group">
        <label>
            <input type="checkbox" name="active" value="1" <?php if(isset($product) && $product->active == '1'): ?>checked <?php endif; ?> >
            Ativo?
        </label>
        </div>

        <div class="form-group">
        <input type="text" name="number" placeholder="N�mero:" class="form-control" value="<?php echo e(isset($product->name) ? $product->name : old('number')); ?>">
        </div>

        <div class="form-group">
        <select name="category" class="form-control">
            <option>Escolha a Categoria</option>
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category); ?>"

                    <?php if( isset($product) && $product->category == $category ): ?>
                        selected
                    <?php endif; ?>

                        ><?php echo e($category); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>

        <div class="form-group">
        <textarea name="description" placeholder ="Descrip.:" class="form-control"><?php echo e(isset($product->description) ? $product->description : old('descrption')); ?></textarea>
        </div>

        <button class="btn btn-primary">Enviar</button>
    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>