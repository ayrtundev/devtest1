@extends('painel.templates.template')

@section('content')

    <doctype  html>

<!--        <charset utf-8> importante deixar como post(tenta forjar envio de dado, nao enviou token, especificar
 token se � autentico) o metodo devido ao ataque crf erro proposital -->

    <h1 class="title-pg">Gest�o de produtos</h1>
        <!-- Verificar uma vari�vel quando enviado para c� envia errors. o erro de tabula��o s�o recuperados pelo loops
           a recupera��o de dados � feito dentro de if.
           -->
        @if( isset($errors) && count($errors) > 0  )
            <div class="alert alert-danger">
                {{-- errors all recupera todas as mensagens de erros e joga em uma vari�vel error --}}
                @foreach( $errors->all() as $error )
                    <p>{{$error}}</p>
                @endforeach
            </div>
        @endif

       @if( isset($product) )
                <form class="form" method="post" aciton="{{route('produtos.update',$product->id)}}">
                    <!-- passa esse m�todo para update. � um helper -->

                    {!! method_field('PUT') !!}

                    @else
                            <form class="form" method="post" action="{{route('produtos.store')}}">
                                @endif

    <!-- Meios para utiliza��o ap�s method="post"  {url{('/painel/produtos')}}  <input type="hidden" name="_token"
    value="csrf_token()"> -->
    <form class="form"  method="post"    action="{{route('produtos.store')}}">
        <!-- <input type="hidden" name="_token" value="{csrf_token()}">   ou (!! !!) -->
        {!! csrf_field() !!}
        <div class="form group">
            <!-- Existe um objeto com product name caso n�o exista utilizo o old. Essa mesma l�gica posso utilizar para os outros itens tamb�m {$product->name or -->
            <input type="text" name="name" placeholder="Nome:" class="form-control" value="{{$product->name or old('description')}}">
        </div>

        <div class="form-group">
        <label>
            <input type="checkbox" name="active" value="1" @if(isset($product) && $product->active == '1')checked @endif >
            Ativo?
        </label>
        </div>

        <div class="form-group">
        <input type="text" name="number" placeholder="N�mero:" class="form-control" value="{{$product->name or old('number')}}">
        </div>

        <div class="form-group">
        <select name="category" class="form-control">
            <option>Escolha a Categoria</option>
            @foreach($categorys as $category)
                <option value="{{$category}}"

                    @if( isset($product) && $product->category == $category )
                        selected
                    @endif

                        >{{$category}}</option>
            @endforeach
        </select>
        </div>

        <div class="form-group">
        <textarea name="description" placeholder ="Descrip.:" class="form-control">{{$product->description or old('descrption')}}</textarea>
        </div>

        <button class="btn btn-primary">Enviar</button>
    </form>


@endsection