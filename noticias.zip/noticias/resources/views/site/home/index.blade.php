<!-- Jamais fazer abertura de arquivos php aqui dentro. � feio isso  Aqui � feito o html -->

@extends('site.templates.template1')

    @section('content')
        <!-- Aqui vem a m�gina tudo que for colocado dentr section ser� copiado do template -->
    <h1>Home page do site</h1>
{{-- This comment will not be in the rendered HTML {!! $xss !!} --}} <!--   Usar esse caso quando a vari�vel n�o colocar em risco nosso sistema  -->
    @if($var1 == '122' )
    <p>e igual</p>
        @else
        <p>diferente</p>
        @endif
        @unless( $var1 == 1234)
            <p>Nao e igual....unless</p>
            @endunless
        @foreach($dados as $array)
            <p>Valor: {{$array}}</p>
            @endforeach
           @push('scripts')
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            @endpush    {{-- super recomenda esse recurso do laravel e deixa a palia��o mais leve --}}
    @endsection