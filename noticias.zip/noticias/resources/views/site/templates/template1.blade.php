    <!DOCTYPE html>
    <!-- <charset = 'utf-8'>'-->
<html>
    <head>
        <title> {{$tituloarb or 'Curso de Laravel 5.3'}} </title>
    </head>
    <body>
        <!-- usar esse arquivo como template do site    nunca utilizar na entrada de usu�rio-->

        @yield('content')
        @stack('scripts')

    </body>
</html>
