@extends('site.templates.template1')

@section('content')
    <h1>Pg contato</h1>
    @endsection